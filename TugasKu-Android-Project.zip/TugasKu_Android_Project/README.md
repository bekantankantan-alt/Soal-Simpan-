# TugasKu UT — Android WebView APK

Project Android yang membungkus HTML TugasKu sebagai aplikasi Android. Ikon PNG launcher sudah disertakan sebagai ikon aplikasi di Home Android.

## Build APK lewat GitHub Actions
1. Ekstrak ZIP ini.
2. Upload **isi folder `TugasKu_Android_Project`** ke root repository GitHub (jangan upload ZIP sebagai satu file).
3. Pastikan `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions** → workflow **Build TugasKu APK** → **Run workflow**.
5. Setelah selesai, buka run yang sukses dan unduh artifact **TugasKuUT-debug-apk**. Di dalamnya ada `app-debug.apk`.

Workflow juga otomatis build ketika kamu push ke branch `main`.

## Data dan fitur
- HTML terbaru: navigasi bawah selalu melayang, tugas selesai dipisah dari tugas aktif, menu download cover Word asli.
- WebView mengaktifkan JavaScript dan DOM storage; HTML menggunakan penyimpanan lokal browser (localStorage) untuk data tugas pada perangkat yang sama.
- OCR menggunakan Tesseract.js dari CDN dan perlu internet.
- APK debug untuk instalasi/pengujian pribadi.
